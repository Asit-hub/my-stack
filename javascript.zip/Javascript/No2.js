function convertMinutestoSeconds(minutes) 
    {
      return Math.floor(minutes * 60);
    }
    var minutesToSeconds = convertMinutestoSeconds(2); // convert minutes to second javascript 
    document.write( "Result of converting minutes to seconds :- " + minutesToSeconds ); 
 