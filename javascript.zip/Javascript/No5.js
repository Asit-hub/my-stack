var arr = [0, 1, 2, 3].reverse();
document.write("Reversed array is : " + arr );