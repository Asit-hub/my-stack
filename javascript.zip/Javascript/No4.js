let str="program to search for a particular character in astring"
console.log(str.indexOf("f"));
console.log(str.includes("a"));