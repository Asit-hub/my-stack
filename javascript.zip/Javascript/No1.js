function myFunction() {
  var str = "Visit Schools!"; 
  var n = str.search("Schools");
  document.getElementById("demo").innerHTML = n;
}